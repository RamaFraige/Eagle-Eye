from .usecase import ObjectDetection

__all__ = [
    "ObjectDetection",
]
