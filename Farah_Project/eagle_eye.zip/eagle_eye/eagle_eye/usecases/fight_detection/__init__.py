from .usecase import FightDetection

__all__ = ["FightDetection"]
